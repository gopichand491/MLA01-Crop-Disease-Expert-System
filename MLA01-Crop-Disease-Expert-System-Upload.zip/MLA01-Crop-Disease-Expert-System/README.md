# MLA01 – Crop Disease Expert System

**Course:** Artificial Intelligence and Expert Systems (MLA01)  
**CO5:** Rule-based expert systems, production rules, forward/backward chaining, and procedural/non-procedural paradigms.  
**Selected problem:** Agricultural Crop Disease Diagnosis (Assignment 5, Question 5).

## Overview
Educational Prolog prototype using a fictional tomato-plant example. It considers crop type, dark leaf spots, yellow leaves, field humidity, prolonged leaf wetness, wilting, soil moisture and insect damage.

**Safety note:** These are illustrative academic rules, not validated agricultural diagnoses. Do not use them alone to choose pesticides or chemical treatments. Confirm real crop problems with an agricultural expert.

## Structure
```text
README.md
src/crop_diagnosis.pl
tests/test_cases.md
docs/knowledge_base.md
docs/inference_demo.md
.gitignore
```

## Requirement
Install SWI-Prolog: https://www.swi-prolog.org/

## Run
From the repository folder, open SWI-Prolog and load:
```prolog
?- [src/crop_diagnosis].
```
Try:
```prolog
?- suspect_leaf_disease(p1).
?- suspect_moisture_associated_leaf_disease(p1).
?- suspect_water_stress(p1).
?- suspect_pest_damage(p1).
?- explain_diagnosis(p1, Explanation).
```

Expected sample results: first two succeed; water-stress and pest-damage queries fail because their required positive facts are not supplied. See `tests/test_cases.md`.

## Assignment mapping
- Production rules: `docs/knowledge_base.md`
- Propositional and first-order logic: `docs/knowledge_base.md` and the assignment report
- Prolog facts, rules and queries: `src/crop_diagnosis.pl`
- Forward/backward chaining explanation: `docs/inference_demo.md`

## Limitations
The prototype uses a small symbolic rule set. Future work can add unknown-value handling, confidence scores, expert-validated regional rules, more crops and varieties, and image evidence as supplementary input.

## Repository URL
https://github.com/gopichand491/MLA01-Crop-Disease-Expert-System

**Student:** Gopi Chand
