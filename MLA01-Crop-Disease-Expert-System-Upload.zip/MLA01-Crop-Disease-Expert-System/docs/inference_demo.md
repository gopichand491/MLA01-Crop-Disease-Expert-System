# Inference Demonstration

## Forward chaining (data-driven)
Initial facts: tomato(p1), dark_spots(p1), yellow_leaves(p1), planted_in(p1, field_a), high_humidity(field_a), prolonged_leaf_wetness(field_a).

1. Put observations in working memory.
2. Match tomato + dark spots + yellow leaves.
3. Derive suspect_leaf_disease(p1).
4. Match dark spots + field association + high humidity + prolonged wetness.
5. Derive suspect_moisture_associated_leaf_disease(p1).
6. Water-stress and pest rules do not fire because their required positive facts are absent.

## Backward chaining (goal-driven)
Goal: prove suspect_leaf_disease(p1).
1. Select the rule with head suspect_leaf_disease(Plant).
2. Substitute Plant = p1.
3. Prove crop(p1, tomato), dark_spots(p1), yellow_leaves(p1).
4. Each subgoal matches a stored fact.
5. Therefore the goal succeeds.

**Implementation note:** The Prolog program uses goal-directed execution (backward chaining). The forward-chaining sequence above is a manual rule-firing demonstration, not a separate forward-chaining engine.
