# Knowledge Base Design

## Entities
Plant (`p1`), crop (tomato), field (`field_a`), observations (spots, yellowing, wilting), environment (humidity, leaf wetness), and inferred diagnosis.

## Sample facts
`crop(p1, tomato).`  
`planted_in(p1, field_a).`  
`dark_spots(p1).`  
`yellow_leaves(p1).`  
`high_humidity(field_a).`  
`prolonged_leaf_wetness(field_a).`

## Production-rule examples
1. IF tomato AND dark spots AND yellow leaves, THEN suspect a leaf disease.
2. IF dark spots AND high humidity AND prolonged leaf wetness, THEN suspect a moisture-associated leaf disease.
3. IF wilting AND low soil moisture, THEN suspect water stress.
4. IF insect damage AND insects observed, THEN suspect pest damage.

## Propositional logic
T: tomato; S: dark spots; Y: yellow leaves; H: high humidity; W: prolonged wetness; F: leaf disease suspected.

`(T AND S AND Y) -> F`  
`(S AND H AND W) -> F`

## First-order logic
`forall x ((Tomato(x) AND HasDarkSpots(x) AND HasYellowLeaves(x)) -> SuspectLeafDisease(x))`

The rules are simplified teaching examples and are not validated plant-pathology rules.
