% MLA01 Assignment 5 - Agricultural Crop Disease Diagnosis
% Educational Prolog knowledge base. Load: ?- [src/crop_diagnosis].

% Sample facts
crop(p1, tomato).
planted_in(p1, field_a).
dark_spots(p1).
yellow_leaves(p1).
high_humidity(field_a).
prolonged_leaf_wetness(field_a).
not_wilting(p1).
no_insect_damage(p1).

% Diagnostic rules
suspect_leaf_disease(Plant) :-
    crop(Plant, tomato),
    dark_spots(Plant),
    yellow_leaves(Plant).

suspect_moisture_associated_leaf_disease(Plant) :-
    dark_spots(Plant),
    planted_in(Plant, Field),
    high_humidity(Field),
    prolonged_leaf_wetness(Field).

suspect_water_stress(Plant) :-
    wilting(Plant),
    planted_in(Plant, Field),
    low_soil_moisture(Field).

suspect_pest_damage(Plant) :-
    insect_damage(Plant),
    planted_in(Plant, Field),
    insects_observed(Field).

preliminary_alert(Plant) :-
    suspect_leaf_disease(Plant).

explain_diagnosis(Plant,
 'Tomato plant has dark leaf spots and yellow leaves; a leaf disease is suspected for further inspection.') :-
    suspect_leaf_disease(Plant).

% Example queries:
% ?- suspect_leaf_disease(p1).                         % true
% ?- suspect_moisture_associated_leaf_disease(p1).     % true
% ?- suspect_water_stress(p1).                         % false
% ?- suspect_pest_damage(p1).                          % false
% ?- explain_diagnosis(p1, Explanation).
