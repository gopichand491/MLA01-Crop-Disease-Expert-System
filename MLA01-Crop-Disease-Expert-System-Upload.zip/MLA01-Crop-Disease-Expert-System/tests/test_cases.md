# Test Cases

| ID | Query | Expected result | Reason |
|---|---|---|---|
| TC01 | `?- suspect_leaf_disease(p1).` | `true.` | Tomato, dark spots and yellow leaves are facts. |
| TC02 | `?- suspect_moisture_associated_leaf_disease(p1).` | `true.` | Dark spots, field association, high humidity and prolonged wetness are present. |
| TC03 | `?- suspect_water_stress(p1).` | `false.` | `wilting(p1)` and `low_soil_moisture(field_a)` are not supplied. |
| TC04 | `?- suspect_pest_damage(p1).` | `false.` | Insect damage and insect observation facts are not supplied. |
| TC05 | `?- preliminary_alert(p1).` | `true.` | Leaf-disease rule succeeds. |
| TC06 | `?- explain_diagnosis(p1, Explanation).` | Explanation returned | The rule provides a human-readable explanation. |

Load using `?- [src/crop_diagnosis].` Run each query separately. Capture your actual SWI-Prolog console screenshots for submission. Do not claim screenshots or execution were completed unless you run them yourself.
